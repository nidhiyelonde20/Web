function change_availiblity_to_no(x){
	var a = document.getElementById(x);
	a.innerHTML = "Availiblity: No";
}